# Marathi EdTech Platform — Pilot City: Solapur

An AI-native learning platform for Marathi-medium students in Maharashtra. Students get an interactive tutor ("AI Guru / Mitra") that speaks Marathi, teachers get attendance and progress tools, parents get a weekly WhatsApp report, and the whole thing is built to run on nearly free infrastructure until it earns its keep.

See `docs/ARCHITECTURE.md` for the full design, `docs/DEPLOYMENT.md` for step-by-step hosting, and `docs/ANTIGRAVITY_PROMPT.md` to hand this spec to an agentic coding IDE.

## What's in this pack

| File | Purpose |
|---|---|
| `README.md` | This file — overview and quick start |
| `docs/ARCHITECTURE.md` | System design, tech stack rationale, data model, AI/safety design, security, compliance |
| `docs/DEPLOYMENT.md` | Local setup → free-tier pilot hosting → scale-up, with a cost table |
| `docs/ANTIGRAVITY_PROMPT.md` | Copy-paste build prompt for Antigravity IDE / Claude Opus |
| `architecture-diagram.mermaid` | Component diagram of the whole system |
| `ai-cost-optimization-flow.mermaid` | How a student question is answered without hitting the LLM every time |
| `docker-compose.yml` | One-command local environment (Postgres, Redis, backend, realtime gateway) |
| `.env.example` | Every environment variable the stack needs, with no real secrets |

## Roles and what they see

- **Student** — syllabus, assignments, tests, and "AI Guru/Mitra" (text + voice chat in Marathi, restricted to syllabus topics)
- **Teacher** — attendance, test completion, per-student progress/weakness, and a view of what students are asking the AI (for pedagogy and safety)
- **Parent** — one dashboard for multiple children, same progress/weakness view as teachers, weekly WhatsApp report
- **Admin** — syllabus upload/versioning (PDF), user profile management (mobile/email updates)
- **Super Admin** — master data, full AI chat audit access, AI spend dashboard, homepage/marketing content, hidden login URL
- **School Profile** — stubbed in the data model, intentionally not built until a school signs on

## Quick start (local, zero cost)

```bash
git clone <your-repo-url> edtech-platform && cd edtech-platform
cp .env.example .env          # fill in API keys as you get them; Anthropic key is the only one needed on day one
docker compose up --build     # starts Postgres+pgvector, Redis, backend, realtime gateway
```

Frontend runs separately with `npm run dev` inside `/frontend` once it exists (see `docs/ANTIGRAVITY_PROMPT.md` — the actual code for each service is generated there, this pack is the spec and scaffolding).

## Status

- [x] Architecture, tech stack, and cost model defined
- [x] Local dev environment scaffolded (docker-compose)
- [ ] Auth + Student dashboard + AI Guru (Phase 1 build)
- [ ] Teacher + Parent dashboards (Phase 2)
- [ ] Admin + Super Admin (Phase 3)
- [ ] Payments + WhatsApp reports (Phase 4)
- [ ] Free-tier pilot deploy (Phase 5)
- [ ] School Profile module (later, only once a school signs on)
